package com.cineverse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CineVerseApiManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
