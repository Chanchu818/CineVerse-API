package com.cineverse.service;

import java.util.List;

import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import com.cineverse.entity.Movie;
import com.cineverse.exception.MovieNotFoundException;
import com.cineverse.repository.MovieRepository;

@Service
public class MovieServiceImpl implements MovieService {
	
	private final MovieRepository movieRepository;
	
	public MovieServiceImpl(MovieRepository movieRepository) {
		this.movieRepository=movieRepository;
		
	}
	
	
	public Movie addMovie(Movie movie) {
		return movieRepository.save(movie);
	}
	
	  public List<Movie> getAllMovies() {
	        return movieRepository.findAll();
	    }

	  
	    public Movie getMovieById(Long id) {
	        return movieRepository.findById(id)
	                .orElseThrow(() ->
	                        new MovieNotFoundException("Movie not found with ID : " + id));
	    }

	 
	    public Movie updateMovie(Long id, Movie movie) {

	        Movie existingMovie = getMovieById(id);

	        existingMovie.setTitle(movie.getTitle());
	        existingMovie.setGenre(movie.getGenre());
	        existingMovie.setLanguage(movie.getLanguage());
	        existingMovie.setReleaseYear(movie.getReleaseYear());
	        existingMovie.setRating(movie.getRating());
	        existingMovie.setDuration(movie.getDuration());
	        existingMovie.setDirector(movie.getDirector());

	        return movieRepository.save(existingMovie);
	    }

	   
	    public void deleteMovie(Long id) {

	        Movie movie = getMovieById(id);
	        movieRepository.delete(movie);
	    }

	    public List<Movie> getMoviesByGenre(String genre) {
	        return movieRepository.findByGenreIgnoreCase(genre);
	    }

	   
	    public List<Movie> getMoviesByLanguage(String language) {
	        return movieRepository.findByLanguageIgnoreCase(language);
	    }

	    
	    public List<Movie> getMoviesByDirector(String director) {
	        return movieRepository.findByDirectorIgnoreCase(director);
	    }

	    
	    public List<Movie> getMoviesByRating(Double rating) {
	        return movieRepository.findByRatingGreaterThanEqual(rating);
	    }

	    
	    public List<Movie> getMoviesByYear(Integer year) {
	        return movieRepository.findByReleaseYear(year);
	    }

	    
	    public Page<Movie> getMovies(int page, int size, String sortBy) {

	        Pageable pageable =
	                PageRequest.of(page, size, Sort.by(sortBy));

	        return movieRepository.findAll(pageable);
	    }

	 
	    public List<Movie> searchMovie(String title) {
	        return movieRepository.findByTitleContainingIgnoreCase(title);
	    }

	   
	    public List<Movie> getTopRatedMovies() {
	        return movieRepository.findTop5ByOrderByRatingDesc();
	    }

	    
	    public List<Movie> getLatestMovies() {
	        return movieRepository.findTop5ByOrderByReleaseYearDesc();
	    }

	    
	    public long countMoviesByGenre(String genre) {
	        return movieRepository.countByGenreIgnoreCase(genre);
	    }
	

}
