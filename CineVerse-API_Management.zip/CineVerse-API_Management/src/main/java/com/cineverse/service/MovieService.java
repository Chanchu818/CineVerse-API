package com.cineverse.service;

import java.util.List;

import org.springframework.data.domain.Page;

//import org.hibernate.query.Page;

import com.cineverse.entity.Movie;

public interface MovieService {
	
	Movie addMovie(Movie movie);

	List<Movie>getAllMovies();
	
	Movie getMovieById(Long id);
	
	Movie updateMovie(Long id,Movie movie);
	
	void deleteMovie(Long id);
	
	List<Movie> getMoviesByGenre(String genre);
	
	List<Movie> getMoviesByLanguage(String language);
	
	List<Movie> getMoviesByDirector(String director);
	
	List<Movie> getMoviesByRating(Double rating);
	
	List<Movie> getMoviesByYear(Integer year);
	
	
	Page<Movie>getMovies(int page, int size, String sortBy);
	
	List<Movie> searchMovie(String title);
	
	List<Movie> getTopRatedMovies();
	
	List<Movie> getLatestMovies();
	
	long countMoviesByGenre(String genre);
	
	
}
