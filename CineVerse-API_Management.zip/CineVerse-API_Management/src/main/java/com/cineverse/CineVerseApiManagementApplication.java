package com.cineverse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CineVerseApiManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CineVerseApiManagementApplication.class, args);
	}

}

