
package com.cineverse.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI cineVerseOpenAPI() {

        Contact contact = new Contact();
        contact.setName("CineVerse Development Team");

        Info info = new Info()
                .title("CineVerse API")
                .version("1.0")
                .description(
                        "REST API for managing movies. " +
                        "This API supports CRUD operations, " +
                        "filtering, pagination, sorting and validation."
                )
                .contact(contact);

        return new OpenAPI()
                .info(info);
    }
}
