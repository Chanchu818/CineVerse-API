package com.cineverse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name="movies")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Movie {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message="Title is required")
	@Column(nullable=false)
	private String title;
	
	 @NotBlank(message = "Genre is required")
	private String genre;
	 
	@NotBlank(message = "Language is required")
	@Column(nullable = false)
	private String language;
	

    @Min(value = 1900, message = "Release year must be greater than or equal to 1900")
    @Column(nullable = false)
	private Integer releaseYear;
    

    @DecimalMin(value = "0.0", message = "Rating must be at least 0")
    @DecimalMax(value = "10.0", message = "Rating cannot exceed 10")
    @Column(nullable = false)
	private Double rating;
    
    @Min(value = 1, message = "Duration must be at least 1 minute")
    @Column(nullable = false)
	private Integer duration;
    
    @NotBlank(message = "Director name is required")
    @Column(nullable = false)
	private String director;

	public Movie() {
		
	}

	public Movie(Long id, @NotBlank(message = "Title is required") String title,
			@NotBlank(message = "Genre is required") String genre,
			@NotBlank(message = "Language is required") String language,
			@Min(value = 1900, message = "Release year must be greater than or equal to 1900") Integer releaseYear,
			@DecimalMin(value = "0.0", message = "Rating must be at least 0") @DecimalMax(value = "10.0", message = "Rating cannot exceed 10") Double rating,
			@Min(value = 1, message = "Duration must be at least 1 minute") Integer duration,
			@NotBlank(message = "Director name is required") String  director) {

		this.id = id;
		this.title = title;
		this.genre = genre;
		this.language = language;
		this.releaseYear = releaseYear;
		this.rating = rating;
		this.duration = duration;
		this. director =  director;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Integer getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(Integer releaseYear) {
		this.releaseYear = releaseYear;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String  director) {
		this. director =  director;
	}
    
    

}
