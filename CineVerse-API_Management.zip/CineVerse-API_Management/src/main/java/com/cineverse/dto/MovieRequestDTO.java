package com.cineverse.dto;

public class MovieRequestDTO {
	

}
