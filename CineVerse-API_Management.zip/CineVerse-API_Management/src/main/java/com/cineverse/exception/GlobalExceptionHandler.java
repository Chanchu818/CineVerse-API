package com.cineverse.exception;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.MethodArgumentNotValidException;
	import org.springframework.web.bind.annotation.ExceptionHandler;
	import org.springframework.web.bind.annotation.RestControllerAdvice;

	import java.util.HashMap;
	import java.util.Map;

	@RestControllerAdvice
	public class GlobalExceptionHandler {

	    // Movie Not Found
	    @ExceptionHandler(MovieNotFoundException.class)
	    public ResponseEntity<Map<String, Object>> handleMovieNotFound(
	            MovieNotFoundException ex) {

	        Map<String, Object> response = new HashMap<>();

	        response.put("status", HttpStatus.NOT_FOUND.value());
	        response.put("error", "Not Found");
	        response.put("message", ex.getMessage());

	        return new ResponseEntity<>(
	                response,
	                HttpStatus.NOT_FOUND
	        );
	    }

	    // Validation Errors
	    @ExceptionHandler(MethodArgumentNotValidException.class)
	    public ResponseEntity<Map<String, Object>> handleValidationErrors(
	            MethodArgumentNotValidException ex) {

	        Map<String, Object> errors = new HashMap<>();

	        ex.getBindingResult()
	                .getFieldErrors()
	                .forEach(error ->
	                        errors.put(
	                                error.getField(),
	                                error.getDefaultMessage()
	                        )
	                );

	        Map<String, Object> response = new HashMap<>();

	        response.put("status", HttpStatus.BAD_REQUEST.value());
	        response.put("error", "Validation Failed");
	        response.put("messages", errors);

	        return new ResponseEntity<>(
	                response,
	                HttpStatus.BAD_REQUEST
	        );
	    }

	    // Illegal Arguments
	    @ExceptionHandler(IllegalArgumentException.class)
	    public ResponseEntity<Map<String, Object>> handleIllegalArgument(
	            IllegalArgumentException ex) {

	        Map<String, Object> response = new HashMap<>();

	        response.put("status", HttpStatus.BAD_REQUEST.value());
	        response.put("error", "Bad Request");
	        response.put("message", ex.getMessage());

	        return new ResponseEntity<>(
	                response,
	                HttpStatus.BAD_REQUEST
	        );
	    }

	    // Generic Exception
	    @ExceptionHandler(Exception.class)
	    public ResponseEntity<Map<String, Object>> handleGenericException(
	            Exception ex) {

	        Map<String, Object> response = new HashMap<>();

	        response.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
	        response.put("error", "Internal Server Error");
	        response.put("message", ex.getMessage());

	        return new ResponseEntity<>(
	                response,
	                HttpStatus.INTERNAL_SERVER_ERROR
	        );
	    }
	

}
