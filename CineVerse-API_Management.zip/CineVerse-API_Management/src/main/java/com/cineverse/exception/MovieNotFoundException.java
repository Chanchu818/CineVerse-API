//package com.cineverse.exception;
//
//public class MovieNotFoundException extends RuntimeException
//	public MovieNotFoundEception(String message) {
//		super(message);
//	
//	return movieRepository.findById(id)
//	        .orElseThrow(() ->
//	                new MovieNotFoundException(
//	                        "Movie not found with ID: " + id
//	                )
//	        );
//	
//}
//}
package com.cineverse.exception;

public class MovieNotFoundException extends RuntimeException {

    public MovieNotFoundException(String message) {
        super(message);
    }
}