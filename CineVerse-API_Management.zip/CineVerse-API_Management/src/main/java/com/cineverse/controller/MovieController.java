package com.cineverse.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cineverse.entity.Movie;
import com.cineverse.service.MovieService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/movies")
@Tag(name="Movie Management",description="APIs for managing movies")
public class MovieController {

	private final MovieService movieService;
	
	public MovieController(MovieService movieService) {
		this.movieService=movieService;
		
	}
	@PostMapping
	@Operation(
			summary="Add a new Movie",
			description = "Creates a new movie in the database"
			)
			 @ApiResponses({
		            @ApiResponse(responseCode = "201", description = "Movie created successfully"),
		            @ApiResponse(responseCode = "400", description = "Invalid movie data")
		    })
		    public ResponseEntity<Movie> addMovie(
		            @Valid @RequestBody Movie movie) {

		        Movie savedMovie = movieService.addMovie(movie);

		        return new ResponseEntity<>(
		                savedMovie,
		                HttpStatus.CREATED
		        );
	}

    @GetMapping
    @Operation(
            summary = "Get movies",
            description = "Get all movies with optional pagination and sorting"
    )
    @ApiResponse(
            responseCode = "200",
            description = "Movies retrieved successfully"
    )
    public ResponseEntity<?> getMovies(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy) {

        Page<Movie> movies = movieService.getMovies(
                page,
                size,
                sortBy
        );

        return ResponseEntity.ok(movies);
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Get movie by ID",
            description = "Returns a movie using its ID"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Movie found"),
            @ApiResponse(responseCode = "404", description = "Movie not found")
    })
    public ResponseEntity<Movie> getMovieById(
            @PathVariable Long id) {

        Movie movie = movieService.getMovieById(id);

        return ResponseEntity.ok(movie);
    }
	
    

    @PutMapping("/{id}")
    @Operation(
            summary = "Update movie",
            description = "Updates an existing movie"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Movie updated successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid movie data"),
            @ApiResponse(responseCode = "404", description = "Movie not found")
    })
    public ResponseEntity<Movie> updateMovie(
            @PathVariable Long id,
            @Valid @RequestBody Movie movie) {

        Movie updatedMovie = movieService.updateMovie(
                id,
                movie
        );

        return ResponseEntity.ok(updatedMovie);
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Delete movie",
            description = "Deletes a movie using its ID"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Movie deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Movie not found")
    })
    public ResponseEntity<Void> deleteMovie(
            @PathVariable Long id) {

        movieService.deleteMovie(id);

        return ResponseEntity.noContent().build();
    }

    
    @GetMapping("/genre/{genre}")
    @Operation(
            summary = "Get movies by genre",
            description = "Returns movies belonging to a specific genre"
    )
    public ResponseEntity<List<Movie>> getMoviesByGenre(
            @PathVariable String genre) {

        return ResponseEntity.ok(
                movieService.getMoviesByGenre(genre)
        );
    }
    
    
	@GetMapping("/language/{language}")
	@Operation(
			summary = "Get Movies by language",
			description ="Return movies in a specific language"
			)
	public ResponseEntity<List<Movie>> getMoviesByLanguage(@PathVariable String language){
		return ResponseEntity.ok(
				movieService.getMoviesByLanguage(language)
				);
	}
	
	@GetMapping("/director/{director}")
	@Operation(
			summary = "Get Movies by language",
			description ="Return movies in a specific language"
			)
	public ResponseEntity<List<Movie>> getMoviesByDirector(@PathVariable String director){
		return ResponseEntity.ok(
				movieService.getMoviesByLanguage(director)
				);
	
	
}
	 @GetMapping("/rating/{rating}")
	    @Operation(
	            summary = "Get movies by rating",
	            description = "Returns movies with rating greater than or equal to the given rating"
	    )
	    public ResponseEntity<List<Movie>> getMoviesByRating(
	            @PathVariable Double rating) {

	        return ResponseEntity.ok(
	                movieService.getMoviesByRating(rating)
	        );
	    }

	 @GetMapping("/year/{year}")
	    @Operation(
	            summary = "Get movies by release year",
	            description = "Returns movies released in a specific year"
	    )
	    public ResponseEntity<List<Movie>> getMoviesByYear(
	            @PathVariable Integer year) {

	        return ResponseEntity.ok(
	                movieService.getMoviesByYear(year)
	        );
	    }
	 
	 @GetMapping("/search")
	    @Operation(
	            summary = "Search movies by title",
	            description = "Searches movies whose title contains the given text"
	    )
	    public ResponseEntity<List<Movie>> searchMovie(
	            @RequestParam String title) {

	        return ResponseEntity.ok(
	                movieService.searchMovie(title)
	        );
	    }
	 
	  @GetMapping("/top-rated")
	    @Operation(
	            summary = "Get top rated movies",
	            description = "Returns the top 5 highest rated movies"
	    )
	    public ResponseEntity<List<Movie>> getTopRatedMovies() {

	        return ResponseEntity.ok(
	                movieService.getTopRatedMovies()
	        );
	    }
	  
	  @GetMapping("/latest")
	    @Operation(
	            summary = "Get latest movies",
	            description = "Returns the latest 5 movies based on release year"
	    )
	    public ResponseEntity<List<Movie>> getLatestMovies() {

	        return ResponseEntity.ok(
	                movieService.getLatestMovies()
	        );
	    }
	  
	  @GetMapping("/count/genre/{genre}")
	    @Operation(
	            summary = "Count movies by genre",
	            description = "Returns the number of movies in a genre"
	    )
	    public ResponseEntity<Long> countMoviesByGenre(
	            @PathVariable String genre) {

	        return ResponseEntity.ok(
	                movieService.countMoviesByGenre(genre)
	        );
	    }
}
